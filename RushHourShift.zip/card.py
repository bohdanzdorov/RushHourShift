from enum import Enum

class Card(Enum):
    MOVE = 0
    SLIDE = 1
    MOVEANDSHIFT = 2
    SHIFT = 3